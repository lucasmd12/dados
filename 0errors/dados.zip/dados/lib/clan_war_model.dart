import 'package:lucasbeatsfederacao/models/clan_model.dart';

enum ClanWarStatus {
  pending,
  active,
  completed,
  cancelled,
}

class ClanWarModel {
  final String id;
  final String challengerClanId;
  final String challengedClanId;
  final DateTime startTime;
  final DateTime endTime;
  final ClanWarStatus status;
  final String? winnerClanId;
  final String? description;
  final Clan? challengerClan; // Opcional, para incluir dados do clã desafiante
  final Clan? challengedClan; // Opcional, para incluir dados do clã desafiado
  final Clan? winnerClan; // Opcional, para incluir dados do clã vencedor, se disponível

  ClanWarModel({
    required this.id,
    required this.challengerClanId,
    required this.challengedClanId,
    required this.startTime,
    required this.endTime,
    required this.status,
    this.winnerClanId,
    this.description,
    this.challengerClan, // Opcional, para incluir dados do clã desafiante
    this.challengedClan, // Opcional, para incluir dados do clã desafiado
    this.winnerClan, // Opcional, para incluir dados do clã vencedor, se disponível
  });

  factory ClanWarModel.fromJson(Map<String, dynamic> json) {
    return ClanWarModel(
      id: json["id"] as String,
      challengerClanId: json["challengerClanId"] as String,
      challengedClanId: json["challengedClanId"] as String,
      startTime: DateTime.parse(json["startTime"] as String),
      endTime: DateTime.parse(json["endTime"] as String),
      status: ClanWarStatus.values.firstWhere(
          (e) => e.toString().split(".").last == json["status"]),
      winnerClanId: json["winnerClanId"] as String?,
 description: json["description"] as String?,
 challengerClan: json["challengerClan"] != null && json["challengerClan"] is Map<String, dynamic>
 ? Clan.fromJson(json["challengerClan"] as Map<String, dynamic>)
 : null,
 winnerClan: json["winnerClan"] != null && json["winnerClan"] is Map<String, dynamic>
 ? Clan.fromJson(json["winnerClan"] as Map<String, dynamic>)
 : null,
 challengedClan: json["challengedClan"] != null && json["challengedClan"] is Map<String, dynamic>
 ? Clan.fromJson(json["challengedClan"] as Map<String, dynamic>)
 : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      "id": id,
      "challengerClanId": challengerClanId,
      "challengedClanId": challengedClanId,
      "startTime": startTime.toIso8601String(),
      "endTime": endTime.toIso8601String(),
      "status": status.toString().split(".").last,
      "winnerClanId": winnerClanId,
      "description": description,
      "challengerClan": challengerClan?.toJson(),
      "challengedClan": challengedClan?.toJson(),
      "winnerClan": winnerClan?.toJson(), // Adicionado ao toJson
    };
  }
}

