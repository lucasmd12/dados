enum MissionType {
  daily,
  weekly,
  clan,
}