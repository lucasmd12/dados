enum CallUIState {
  idle,
  calling,
  ringing,
  active,
  ended,
  declined,
  missed,
  failed,
}