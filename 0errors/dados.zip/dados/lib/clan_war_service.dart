import 'package:lucasbeatsfederacao/services/api_service.dart';
import 'package:lucasbeatsfederacao/models/clan_war_model.dart';
import 'package:lucasbeatsfederacao/utils/logger.dart';

class ClanWarService {
  final ApiService _apiService;

  ClanWarService(this._apiService);

  Future<ClanWarModel?> createClanWar(Map<String, dynamic> clanWarData) async {
    try {
      final response = await _apiService.post('clan-wars', clanWarData);
      if (response.statusCode == 201) {
        return ClanWarModel.fromJson(response.data);
      } else {
        Logger.error('Failed to create clan war: ${response.data}');
        return null;
      }
    } catch (e, st) {
      Logger.error('Error creating clan war', error: e, stackTrace: st);
      return null;
    }
  }

  Future<List<ClanWarModel>> getClanWars({String? clanId, String? federationId}) async {
    try {
      Map<String, dynamic> queryParams = {};
      if (clanId != null) queryParams['clanId'] = clanId;
      if (federationId != null) queryParams['federationId'] = federationId;

      final response = await _apiService.get('clan-wars', queryParams: queryParams);
      if (response.statusCode == 200) {
        return (response.data as List).map((json) => ClanWarModel.fromJson(json)).toList();
      } else {
        Logger.error('Failed to fetch clan wars: ${response.data}');
        return [];
      }
    } catch (e, st) {
      Logger.error('Error fetching clan wars', error: e, stackTrace: st);
      return [];
    }
  }

  Future<ClanWarModel?> updateClanWar(String id, Map<String, dynamic> updateData) async {
    try {
      final response = await _apiService.put('clan-wars/$id', updateData);
      if (response.statusCode == 200) {
        return ClanWarModel.fromJson(response.data);
      } else {
        Logger.error('Failed to update clan war: ${response.data}');
        return null;
      }
    } catch (e, st) {
      Logger.error('Error updating clan war', error: e, stackTrace: st);
      return null;
    }
  }

  Future<bool> deleteClanWar(String id) async {
    try {
      final response = await _apiService.delete('clan-wars/$id');
      if (response.statusCode == 204) {
        return true;
      } else {
        Logger.error('Failed to delete clan war: ${response.data}');
        return false;
      }
    } catch (e, st) {
      Logger.error('Error deleting clan war', error: e, stackTrace: st);
      return false;
    }
  }
}

