// lib/config/api_config.dart

class ApiConfig {
  static const String baseUrl = "YOUR_API_BASE_URL_HERE"; // Replace with your actual API base URL
  // Add other API configuration constants here if needed
}