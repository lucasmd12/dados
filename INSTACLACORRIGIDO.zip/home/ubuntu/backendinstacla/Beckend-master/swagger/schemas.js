/**
 * @swagger
 * components:
 *   schemas:
 *     UserAdmin:
 *       type: object
 *       properties:
 *         _id:
 *           type: string
 *         username:
 *           type: string
 *         role:
 *           type: string
 *       example:
 *         _id: "665af18a2f4b9a001ea73b9a"
 *         username: "idcloned"
 *         role: "ADM"
 */



/**
 * @swagger
 * components:
 *   schemas:
 *     ClanChatMessage:
 *       type: object
 *       properties:
 *         _id:
 *           type: string
 *           description: ID da mensagem do chat do clã.
 *         channel:
 *           type: string
 *           description: ID do canal do clã.
 *         sender:
 *           type: string
 *           description: ID do remetente da mensagem.
 *         text:
 *           type: string
 *           description: Conteúdo da mensagem de texto.
 *         timestamp:
 *           type: string
 *           format: date-time
 *           description: Data e hora do envio da mensagem.
 *       example:
 *         _id: "60d5ec49f8c7b7001c8e4d1d"
 *         channel: "60d5ec49f8c7b7001c8e4d1a"
 *         sender: "60d5ec49f8c7b7001c8e4d1b"
 *         text: "Olá a todos no clã!"
 *         timestamp: "2023-10-27T10:05:00Z"
 */

/**
 * @swagger
 * components:
 *   schemas:
 *     FederationChatMessage:
 *       type: object
 *       properties:
 *         _id:
 *           type: string
 *           description: ID da mensagem do chat da federação.
 *         channel:
 *           type: string
 *           description: ID do canal da federação.
 *         sender:
 *           type: string
 *           description: ID do remetente da mensagem.
 *         text:
 *           type: string
 *           description: Conteúdo da mensagem de texto.
 *         timestamp:
 *           type: string
 *           format: date-time
 *           description: Data e hora do envio da mensagem.
 *       example:
 *         _id: "60d5ec49f8c7b7001c8e4d1e"
 *         channel: "60d5ec49f8c7b7001c8e4d1f"
 *         sender: "60d5ec49f8c7b7001c8e4d20"
 *         text: "Saudações, membros da federação!"
 *         timestamp: "2023-10-27T10:10:00Z"
 */


