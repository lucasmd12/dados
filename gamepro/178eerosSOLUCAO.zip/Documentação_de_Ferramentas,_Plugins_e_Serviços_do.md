# Documentação de Ferramentas, Plugins e Serviços do Projeto FederacaoMAD

Este documento detalha todas as ferramentas, plugins e serviços identificados no projeto FederacaoMAD, tanto no frontend (Flutter/Dart) quanto no backend (Node.js). Para cada componente, será indicado seu status de uso atual, se foi construído mas está inativo, ou se foi almejado mas ainda não implementado.

## 1. Frontend (Flutter/Dart)

| Componente | Tipo | Descrição/Função | Status | Observações |
|---|---|---|---|---|
| **Flutter SDK** | Ferramenta | Framework de desenvolvimento de UI para aplicativos móveis, web e desktop a partir de uma única base de código. | Em Uso | Core do desenvolvimento do frontend. |
| **Dart SDK** | Ferramenta | Linguagem de programação otimizada para UI, utilizada pelo Flutter. | Em Uso | Linguagem principal do frontend. |
| **cupertino_icons** | Plugin | Conjunto de ícones estilo iOS para Flutter. | Em Uso | Utilizado para elementos de UI. |
| **sentry_flutter** | Plugin | Integração com Sentry para monitoramento de erros e performance em aplicativos Flutter. | Em Uso | Captura e relata erros e transações. |
| **flutter_dotenv** | Plugin | Carrega variáveis de ambiente de um arquivo `.env` para o aplicativo Flutter. | Em Uso | Utilizado para `backendBaseUrl` e outras configurações. |
| **package_info_plus** | Plugin | Fornece informações sobre o pacote do aplicativo (nome, versão, etc.). | Em Uso | Usado para obter informações da versão do app. |
| **firebase_core** | Plugin | Plugin principal do Firebase para Flutter, necessário para inicializar outros serviços Firebase. | Em Uso | Base para integração com Firebase. |
| **firebase_database** | Plugin | Cliente para Firebase Realtime Database. | Em Uso | Potencialmente usado para dados em tempo real. |
| **firebase_messaging** | Plugin | Lida com mensagens push (FCM) para notificações. | Em Uso | Recebimento de notificações. |
| **firebase_auth** | Plugin | Autenticação de usuários com Firebase. | Em Uso | Gerenciamento de autenticação de usuários. |
| **firebase_crashlytics** | Plugin | Relatório de falhas em tempo real para Firebase. | Em Uso | Monitoramento de crashes do app. |
| **firebase_app_check** | Plugin | Protege os serviços de backend do Firebase contra abusos. | Em Uso | Segurança adicional para Firebase. |
| **jitsi_meet_flutter_sdk** | Plugin | Integração com o SDK do Jitsi Meet para funcionalidades de videoconferência. | Em Uso | Habilita chamadas de vídeo/áudio. |
| **http** | Plugin | Cliente HTTP para fazer requisições de rede. | Em Uso | Base para `ApiService` para comunicação com o backend. |
| **socket_io_client** | Plugin | Cliente Socket.IO para comunicação em tempo real com o backend. | Em Uso | Essencial para funcionalidades de chat e VoIP em tempo real. |
| **provider** | Plugin | Gerenciamento de estado para Flutter. | Em Uso | Utilizado para gerenciar o estado da aplicação (e.g., `AuthService`, `ClanService`). |
| **shared_preferences** | Plugin | Armazenamento persistente de dados simples (chave-valor). | Em Uso | Armazenamento de preferências do usuário. |
| **connectivity_plus** | Plugin | Verifica o status da conexão de rede. | Em Uso | Monitoramento da conectividade. |
| **intl** | Plugin | Internacionalização e localização (formatação de datas, números, etc.). | Em Uso | Formatação de dados. |
| **flutter_svg** | Plugin | Renderiza arquivos SVG. | Em Uso | Exibição de gráficos vetoriais. |
| **flutter_chat_ui** | Plugin | Componentes de UI para construção de interfaces de chat. | Em Uso | Base para as telas de chat. |
| **infinite_scroll_pagination** | Plugin | Facilita a implementação de paginação infinita em listas. | Em Uso | Carregamento de dados em listas (e.g., mensagens de chat). |
| **flutter_slidable** | Plugin | Permite adicionar ações deslizáveis a itens de lista. | Em Uso | Funcionalidades de deslizar em listas. |
| **pull_to_refresh** | Plugin | Implementa a funcionalidade de 


pull-to-refresh e load-more. | Em Uso | Atualização de conteúdo em listas. |
| **flutter_sound** | Plugin | Biblioteca para gravação e reprodução de áudio. | Em Uso | Funcionalidades de áudio (gravação/reprodução). |
| **image_picker** | Plugin | Seleciona imagens da galeria ou câmera. | Em Uso | Seleção de imagens para upload. |
| **file_picker** | Plugin | Seleciona arquivos de vários tipos. | Em Uso | Seleção de arquivos para upload. |
| **permission_handler** | Plugin | Gerencia permissões em tempo de execução. | Em Uso | Solicitação de permissões (câmera, microfone, etc.). |
| **flutter_secure_storage** | Plugin | Armazenamento seguro de dados sensíveis (e.g., tokens JWT). | Em Uso | Armazenamento seguro de tokens de autenticação. |
| **flutter_webrtc** | Plugin | Implementação de WebRTC para Flutter. | Em Uso | Base para funcionalidades VoIP (chamadas de voz/vídeo P2P). |
| **uuid** | Plugin | Gera IDs únicos universalmente. | Em Uso | Geração de IDs únicos. |
| **audioplayers** | Plugin | Reprodução de áudio local ou remoto. | Em Uso | Reprodução de sons e áudios. |
| **cached_network_image** | Plugin | Exibe imagens de rede com cache. | Em Uso | Otimização de carregamento de imagens. |
| **flutter_local_notifications** | Plugin | Exibe notificações locais. | Em Uso | Notificações no dispositivo. |
| **just_audio** | Plugin | Reprodutor de áudio robusto para streaming e arquivos locais. | Em Uso | Reprodução de áudio. |
| **flutter_animate** | Plugin | Biblioteca para animações fluidas e declarativas. | Em Uso | Efeitos visuais e animações. |
| **animations** | Plugin | Biblioteca de animações pré-construídas do Google. | Em Uso | Efeitos visuais e transições. |
| **sentry_dart_plugin** | Plugin | Plugin para upload de debug symbols e source maps para Sentry. | Em Uso | Monitoramento de erros e performance. |
| **flutter_launcher_icons** | Ferramenta | Gera ícones de launcher para Android e iOS. | Em Uso | Configuração de ícones do aplicativo. |

## 2. Backend (Node.js)

| Componente | Tipo | Descrição/Função | Status | Observações |
|---|---|---|---|---|
| **Node.js** | Ferramenta | Ambiente de execução JavaScript server-side. | Em Uso | Core do desenvolvimento do backend. |
| **Express** | Framework | Framework web para Node.js, para construção de APIs RESTful. | Em Uso | Base para as rotas e controladores do backend. |
| **Mongoose** | ODM | Object Data Modeling (ODM) para MongoDB, facilita a interação com o banco de dados. | Em Uso | Interação com o MongoDB Atlas. |
| **MongoDB Atlas** | Serviço Externo | Banco de dados NoSQL baseado em nuvem. | Em Uso | Armazenamento de dados do aplicativo. |
| **JWT (jsonwebtoken)** | Biblioteca | Implementação de JSON Web Tokens para autenticação. | Em Uso | Geração e verificação de tokens de autenticação. |
| **bcrypt** | Biblioteca | Hashing de senhas para segurança. | Em Uso | Armazenamento seguro de senhas de usuários. |
| **dotenv** | Biblioteca | Carrega variáveis de ambiente de um arquivo `.env`. | Em Uso | Gerenciamento de configurações sensíveis. |
| **Redis (redis)** | Biblioteca | Cliente para o banco de dados em memória Redis. | Em Uso | Utilizado para cache e gerenciamento de sessões/eventos em tempo real. |
| **Upstash Redis** | Serviço Externo | Serviço Redis serverless e baseado em nuvem. | Em Uso | Provedor do serviço Redis para o backend. |
| **Socket.IO (socket.io)** | Biblioteca | Biblioteca para comunicação bidirecional em tempo real (WebSockets). | Em Uso | Funcionalidades de chat e VoIP em tempo real. |
| **@socket.io/redis-adapter** | Biblioteca | Adaptador Redis para Socket.IO, permite escalar o Socket.IO em múltiplos servidores. | Em Uso | Essencial para a escalabilidade do Socket.IO com Redis. |
| **socket.io-redis** | Biblioteca | (Legado) Adaptador Redis para Socket.IO. | Em Uso | Pode ser uma versão mais antiga ou alternativa ao `@socket.io/redis-adapter`. Verificar qual está sendo ativamente usado. |
| **Firebase Admin SDK (firebase-admin)** | Biblioteca | SDK para interagir com serviços Firebase a partir do backend. | Em Uso | Envio de notificações FCM, gerenciamento de usuários, etc. |
| **Firebase Cloud Messaging (FCM)** | Serviço Externo | Serviço de mensagens push do Firebase. | Em Uso | Envio de notificações para dispositivos móveis. |
| **Cloudinary** | Serviço Externo | Gerenciamento de imagens e vídeos na nuvem. | Em Uso | Armazenamento e entrega de mídias (e.g., fotos de perfil, banners). |
| **multer** | Biblioteca | Middleware para Express para lidar com upload de arquivos `multipart/form-data`. | Em Uso | Processamento de uploads de arquivos. |
| **multer-storage-cloudinary** | Biblioteca | Storage engine para Multer que envia arquivos diretamente para o Cloudinary. | Em Uso | Integração de upload de arquivos com Cloudinary. |
| **axios** | Biblioteca | Cliente HTTP baseado em Promises para o navegador e Node.js. | Em Uso | Fazer requisições HTTP (pode ser usado internamente por outros módulos). |
| **cors** | Middleware | Habilita Cross-Origin Resource Sharing (CORS) para o Express. | Em Uso | Permite que o frontend acesse o backend de diferentes origens. |
| **express-list-endpoints** | Biblioteca | Lista todos os endpoints de uma aplicação Express. | Em Uso | Ferramenta de desenvolvimento/depuração. |
| **express-rate-limit** | Middleware | Limita o número de requisições de um IP para prevenir ataques de força bruta/DDoS. | Em Uso | Segurança e prevenção de abusos. |
| **express-validator** | Biblioteca | Middleware para validação de dados de requisição. | Em Uso | Validação de entrada de dados. |
| **helmet** | Middleware | Coleção de middlewares para Express que ajudam a proteger a aplicação de vulnerabilidades web conhecidas. | Em Uso | Segurança da aplicação. |
| **morgan** | Middleware | Logger de requisições HTTP para Node.js. | Em Uso | Logging de requisições no console. |
| **swagger-jsdoc** | Biblioteca | Gera especificações Swagger/OpenAPI a partir de comentários JSDoc. | Em Uso | Geração de documentação da API. |
| **swagger-ui-express** | Biblioteca | Serve a UI do Swagger para visualizar a documentação da API. | Em Uso | Visualização da documentação da API. |
| **winston** | Biblioteca | Biblioteca de logging versátil para Node.js. | Em Uso | Logging estruturado e avançado. |
| **@sentry/node** | Biblioteca | Integração com Sentry para monitoramento de erros e performance em Node.js. | Em Uso | Captura e relata erros e transações no backend. |
| **@sentry/tracing** | Biblioteca | Funcionalidades de tracing para Sentry. | Em Uso | Monitoramento de performance e rastreamento de transações. |
| **webpack** | Ferramenta | Empacotador de módulos para JavaScript. | Em Uso | Utilizado para build de produção do backend. |
| **nodemon** | Ferramenta | Monitora mudanças no código e reinicia o servidor automaticamente. | Em Uso | Ferramenta de desenvolvimento. |

## 3. Análise de Arquivos `.env` e Configurações

Os arquivos `.env` fornecidos contêm as seguintes configurações, que são cruciais para a operação do backend e a comunicação com serviços externos:

| Variável de Ambiente | Descrição | Status | Observações |
|---|---|---|---|
| `JWT_SECRET` | Chave secreta para assinar e verificar JWTs. | Em Uso | Essencial para a segurança da autenticação. |
| `MONGO_URI` | URI de conexão com o MongoDB Atlas. | Em Uso | Conexão com o banco de dados principal. |
| `PORT` | Porta em que o servidor backend irá rodar. | Em Uso | Configuração de rede do servidor. |
| `REDIS_URL` | URL de conexão com o Redis (Upstash). | Em Uso | Conexão com o serviço de cache/pub-sub. |
| `CLOUDINARY_ENABLED` | Flag para habilitar/desabilitar o Cloudinary. | Em Uso | Controla o uso do Cloudinary. |
| `CLOUDINARY_CLOUD_NAME` | Nome da conta Cloudinary. | Em Uso | Credencial para Cloudinary. |
| `CLOUDINARY_API_KEY` | Chave de API do Cloudinary. | Em Uso | Credencial para Cloudinary. |
| `CLOUDINARY_API_SECRET` | Segredo de API do Cloudinary. | Em Uso | Credencial para Cloudinary. |
| `FIREBASE_SERVER_KEY` | Chave do servidor FCM para envio de notificações. | Em Uso | Credencial para Firebase Cloud Messaging. |
| `FIREBASE_PROJECT_ID` | ID do projeto Firebase. | Em Uso | Identificador do projeto Firebase. |
| `FIREBASE_PRIVATE_KEY_ID` | ID da chave privada para Firebase Admin SDK. | Em Uso | Credencial para Firebase Admin SDK. |
| `FIREBASE_CLIENT_EMAIL` | Email do cliente para Firebase Admin SDK. | Em Uso | Credencial para Firebase Admin SDK. |
| `FIREBASE_CLIENT_ID` | ID do cliente para Firebase Admin SDK. | Em Uso | Credencial para Firebase Admin SDK. |
| `BACKEND_URL` | URL de produção do backend. | Em Uso | Usado para referências externas ou callbacks. |
| `NODE_ENV` | Ambiente de execução (e.g., `development`, `production`). | Em Uso | Configurações específicas do ambiente. |
| `project` | Nome do projeto (e.g., `voip-app`). | Em Uso | Identificador interno do projeto. |

## 4. Serviços de Áudio e Notificação

### 4.1. Serviços de Áudio

*   **Frontend:**
    *   **`flutter_sound`:** Biblioteca para gravação e reprodução de áudio. Indica que o aplicativo pode gravar e reproduzir mensagens de voz ou outros áudios.
    *   **`audioplayers`:** Plugin para reprodução de áudio local ou remoto. Complementa `flutter_sound` ou é usado para reprodução de áudios mais simples (e.g., toques, sons de notificação).
    *   **`just_audio`:** Reprodutor de áudio robusto para streaming e arquivos locais. Provavelmente usado para reprodução de áudio de chamadas VoIP ou streaming de áudio de canais.
    *   **`flutter_webrtc`:** Implementação de WebRTC. **Função:** Permite comunicação de áudio e vídeo em tempo real (P2P) para chamadas VoIP. É a base para a funcionalidade principal de voz do aplicativo.

*   **Backend:**
    *   **Jitsi Meet (via `jitsi_meet_flutter_sdk` no frontend):** Embora o Jitsi seja um serviço externo, o backend pode ter integrações para gerar tokens ou gerenciar salas. A presença de `jitsi_meet_flutter_sdk` no frontend sugere que o Jitsi é o provedor de chamadas de vídeo/áudio. O backend pode ter rotas para gerenciar sessões Jitsi (e.g., criar salas, gerar tokens de autenticação).
    *   **WebRTC (via `flutter_webrtc` no frontend):** O backend precisaria de um servidor de sinalização (provavelmente via Socket.IO) para coordenar as conexões WebRTC entre os clientes. A presença de `voipRoutes.js` e `voip_service.dart` indica que há uma camada de VoIP customizada, possivelmente usando WebRTC diretamente.

### 4.2. Serviços de Notificação

*   **Frontend:**
    *   **`firebase_messaging`:** Plugin para receber notificações push via FCM. **Função:** Permite que o aplicativo receba mensagens do backend, mesmo quando em segundo plano ou fechado.
    *   **`flutter_local_notifications`:** Plugin para exibir notificações locais. **Função:** Usado para exibir notificações recebidas via FCM ou geradas localmente (e.g., chamadas recebidas, mensagens de chat).

*   **Backend:**
    *   **Firebase Admin SDK (`firebase-admin`):** Biblioteca para interagir com o Firebase. **Função:** Usado para enviar notificações push para dispositivos via FCM. A variável `FIREBASE_SERVER_KEY` no `.env` confirma isso.
    *   **`notificationRoutes.js`:** Rotas no backend para gerenciar o envio de notificações.
    *   **`notificationService.js`:** Serviço no backend para encapsular a lógica de envio de notificações.

## 5. Status de Uso e Funcionalidade

Esta seção categoriza as ferramentas e serviços com base em seu status de implementação e funcionalidade.

### 5.1. Ferramentas/Serviços em Uso e Funcionais

Esta categoria inclui todos os componentes que estão ativamente sendo utilizados e parecem cumprir sua função designada no projeto.

*   **Frontend:** Flutter SDK, Dart SDK, cupertino_icons, sentry_flutter, flutter_dotenv, package_info_plus, firebase_core, firebase_database, firebase_messaging, firebase_auth, firebase_crashlytics, firebase_app_check, jitsi_meet_flutter_sdk, http, socket_io_client, provider, shared_preferences, connectivity_plus, intl, flutter_svg, flutter_chat_ui, infinite_scroll_pagination, flutter_slidable, pull_to_refresh, flutter_sound, image_picker, file_picker, permission_handler, flutter_secure_storage, flutter_webrtc, uuid, audioplayers, cached_network_image, flutter_local_notifications, just_audio, flutter_animate, animations, sentry_dart_plugin, flutter_launcher_icons.

*   **Backend:** Node.js, Express, Mongoose, MongoDB Atlas, JWT (jsonwebtoken), bcrypt, dotenv, Redis (redis), Upstash Redis, Socket.IO (socket.io), @socket.io/redis-adapter, Firebase Admin SDK (firebase-admin), Firebase Cloud Messaging (FCM), Cloudinary, multer, multer-storage-cloudinary, axios, cors, express-list-endpoints, express-rate-limit, express-validator, helmet, morgan, swagger-jsdoc, swagger-ui-express, winston, @sentry/node, @sentry/tracing, webpack, nodemon.

### 5.2. Ferramentas/Serviços Construídos mas com Funções Inativas/Incompletas

Esta categoria inclui componentes que foram implementados no código, mas que, devido a erros ou funcionalidades incompletas, não estão operacionais ou não cumprem seu propósito total.

*   **Frontend:**
    *   **`ChatService` (métodos `sendMessage`, `getMessages`, `listenToMessages`, `atualizarStatusPresenca`, `getCachedMessagesForEntity`):** Conforme a análise de erros anterior, esses métodos estão definidos no serviço, mas as chamadas a eles resultam em `undefined_method`. Isso indica que a estrutura está lá, mas a implementação ou a integração completa está faltando ou quebrada. **Função:** Essencial para a funcionalidade de chat.
    *   **`AdminService` (métodos `getUserStats`, `getClanFederationStats`):** Similar ao `ChatService`, esses métodos estão sendo chamados, mas não estão definidos. **Função:** Coleta e exibição de estatísticas administrativas.
    *   **`Message` model (campos `fileSize`, `thumbnailUrl`, `callId`, `callStatus`, `callType`, `callDuration`):** Os getters para esses campos existem, mas retornam `null` ou derivam de `fileUrl` sem um campo direto correspondente no modelo. Isso significa que a funcionalidade de exibir esses detalhes em mensagens (especialmente para chamadas ou arquivos com thumbnails/tamanhos) não está totalmente implementada no modelo de dados. **Função:** Detalhes ricos para mensagens de arquivo e chamadas.
    *   **`VoipService` (variável `token`):** A variável `token` está indefinida, impedindo a autenticação correta das requisições VoIP. **Função:** Autenticação de chamadas VoIP.

*   **Backend:**
    *   **`socket.io-redis`:** Embora `@socket.io/redis-adapter` seja o adaptador mais recente e recomendado, `socket.io-redis` também está listado nas dependências. É possível que um deles seja um resquício ou que haja uma configuração redundante/conflitante. **Função:** Escalabilidade do Socket.IO. É preciso verificar qual está realmente em uso e se o outro é código morto.

### 5.3. Ferramentas/Serviços Almejados mas Não Construídos/Integrados

Esta categoria inclui funcionalidades ou integrações que parecem ter sido planejadas ou seriam benéficas para o projeto, mas que não foram implementadas ou integradas no código atual.

*   **Frontend:**
    *   **Integração de Upload de Arquivos (Multipart/Form-Data):** O método `updateFederationBanner` em `federation_service.dart` tem um `TODO` para implementar o upload de arquivo `multipart/form-data`. Isso indica que a funcionalidade de upload de banners (e possivelmente outras mídias) não está completa. **Função:** Upload de mídias como banners de federação.
    *   **Gerenciamento de Presença Detalhado:** Embora `atualizarStatusPresenca` seja um método ausente no `ChatService`, a ideia de gerenciar o status de presença (online/offline) é almejada, mas a implementação está incompleta. **Função:** Exibir status de presença de usuários.
    *   **`StatsService` (separado):** A menção de `StatsService` como um tipo em `admin_main_dashboard.dart` (mesmo que com erro) sugere que um serviço dedicado a estatísticas pode ter sido almejado, mas não foi totalmente implementado ou integrado como um tipo válido. **Função:** Centralizar a lógica de estatísticas.

*   **Backend:**
    *   **Servidor de Sinalização WebRTC Completo:** Embora o Socket.IO esteja em uso e haja rotas VoIP, a complexidade de um servidor de sinalização WebRTC completo para chamadas P2P pode exigir mais do que o que está atualmente implementado, especialmente para funcionalidades avançadas como NAT traversal (STUN/TURN). **Função:** Conexões P2P robustas para VoIP.
    *   **Monitoramento de Performance Avançado:** Embora Sentry esteja integrado, a presença de `performanceMiddleware.js` no backend sugere um desejo por monitoramento de performance mais granular, que pode não estar totalmente configurado ou utilizado. **Função:** Otimização e diagnóstico de gargalos de performance.
    *   **`spiritualMiddleware.js` e `spiritualLogger.js`:** A existência desses arquivos sugere uma intenção de adicionar funcionalidades ou logging com um tema específico, mas sua funcionalidade e uso precisam ser verificados para determinar se estão ativos ou são código morto. **Função:** Funcionalidades/logging com tema específico.

## 6. Conclusão

O projeto FederacaoMAD possui uma base sólida de ferramentas e serviços, tanto no frontend quanto no backend, com forte dependência de tecnologias como Flutter, Node.js, MongoDB, Firebase e Redis. A maioria dos componentes essenciais está em uso. No entanto, a análise revela áreas críticas onde a implementação está incompleta ou quebrada, especialmente nas funcionalidades de chat e VoIP, que são centrais para o aplicativo. Além disso, há indícios de funcionalidades almejadas que ainda não foram totalmente construídas ou integradas. A correção desses pontos será fundamental para a estabilidade e a funcionalidade plena do FederacaoMAD.

