# Documento de Visão e Histórico do Projeto FederacaoMAD

## 1. Introdução e Propósito do Documento

Este documento tem como objetivo fornecer uma visão abrangente e detalhada do projeto FederacaoMAD, abordando seu estado atual, o histórico de desenvolvimento, as decisões tomadas, os desafios enfrentados e as intenções futuras. Ele serve como um guia essencial para qualquer desenvolvedor que venha a trabalhar no projeto, garantindo que o contexto, a lógica de negócio e a arquitetura sejam plenamente compreendidos.

O FederacaoMAD é um aplicativo VoIP exclusivo para Android, desenvolvido com Flutter/Dart no frontend e Node.js no backend. Sua natureza "feito à mão" e a colaboração com IAs (incluindo esta) resultaram em um projeto com particularidades íntimas e uma evolução constante, tornando este documento vital para a continuidade e sucesso do desenvolvimento.

## 2. Visão Geral do Projeto FederacaoMAD

O FederacaoMAD é um aplicativo de comunicação VoIP focado em comunidades, clãs e federações. Ele oferece funcionalidades de chat, chamadas de voz, gerenciamento de clãs e federações, e painéis administrativos. A exclusividade e a personalização são características centrais do projeto.

### 2.1. Arquitetura e Tecnologias Principais

*   **Frontend:** Flutter (Dart)
    *   **Versões Compatíveis:** O projeto utiliza versões específicas do Flutter e Dart para garantir compatibilidade e estabilidade.
*   **Backend:** Node.js (JavaScript)
    *   **Frameworks/Bibliotecas:** Express.js (para rotas API, controllers, middlewares).
    *   **Banco de Dados:** MongoDB (MongoDB Atlas).

### 2.2. Regras de Negócio (A "Bíblia" do Backend)

O backend é a fonte fundamental de conhecimento sobre as regras de negócio do FederacaoMAD. Ele define:
*   **Rotas API:** Endpoints para comunicação entre frontend e backend.
*   **Controllers:** Lógica de processamento das requisições.
*   **Middlewares:** Funções executadas antes ou depois dos controllers (ex: autenticação, validação).
*   **Ferramentas e Serviços:** Integrações com serviços externos e lógicas internas.

O frontend é o responsável por acatar as ordens do backend e corrigir seu comportamento com base nas regras de negócio definidas lá. A consistência entre frontend e backend é crucial para a integridade do projeto.

## 3. Histórico de Desenvolvimento e Desafios

O projeto passou por diversas fases de desenvolvimento e enfrentou desafios significativos, especialmente relacionados à manutenção e à introdução de novos recursos.

### 3.1. O "Plano de Legado" e a Explosão de Erros

Inicialmente, havia um plano para corrigir 15 erros, que posteriormente foi atualizado para 18. Este "Plano de Legado" foi criado por um desenvolvedor anterior e serviu como base para as primeiras intervenções. No entanto, a complexidade do projeto e a introdução de novas funcionalidades levaram a um aumento exponencial no número de erros.

*   **Situação Inicial:** 15 erros remanescentes.
*   **Após Atualização:** A contagem de erros saltou para 60, com 45 novos erros não estudados no plano original.
*   **Impacto:** Este aumento repentino indicou a necessidade de uma abordagem mais sistemática e abrangente para a correção de bugs e a manutenção do código.

### 3.2. Análise de Warnings e Infos

Além dos erros críticos, o projeto apresentava uma vasta quantidade de warnings e infos, que, embora não impedissem a compilação, indicavam problemas de qualidade de código, uso de APIs obsoletas e possíveis falhas futuras. Estes foram categorizados em:

*   **Erros de Sintaxe e Lógica:** Problemas que impedem a compilação ou causam comportamento inesperado.
*   **Uso de APIs Obsoletas (`deprecated`):** Funções ou classes que foram descontinuadas e precisam ser atualizadas.
*   **Código Não Utilizado (`unused`):** Código que não é referenciado em nenhum lugar e pode ser removido.
*   **Falta de Documentação:** Áreas do código que carecem de explicações claras.
*   **Problemas de Performance:** Gargalos que podem afetar a fluidez do aplicativo.

## 4. Ferramentas, Plugins e Serviços

O projeto FederacaoMAD integra uma série de ferramentas e serviços, tanto internos quanto externos, para fornecer suas funcionalidades. A seguir, uma análise detalhada:

### 4.1. Backend (Node.js)

| Ferramenta/Serviço | Tipo | Status de Uso | Descrição e Função | Observações | Intenção Original / Futura | 
|---|---|---|---|---|---|
| **Firebase Admin SDK** | Externo | Em Uso | Gerenciamento de usuários, autenticação, notificações push (FCM) e outras funcionalidades de backend do Firebase. | Utiliza `FIREBASE_CLIENT_EMAIL`, `FIREBASE_PRIVATE_KEY_ID`, `FIREBASE_PROJECT_ID`, `FIREBASE_TYPE` do `.env`. | Essencial para autenticação e notificações. | 
| **Firebase FCM (Server Key)** | Externo | Em Uso | Envio de notificações push para dispositivos Android. | Utiliza `FIREBASE_SERVER_KEY` do `.env`. | Fundamental para a comunicação em tempo real e alertas. | 
| **MongoDB Atlas** | Externo | Em Uso | Banco de dados NoSQL para armazenamento de dados do aplicativo (usuários, clãs, mensagens, etc.). | Utiliza `MONGO_URI` do `.env`. | Armazenamento persistente de todos os dados do aplicativo. | 
| **Redis Upstash** | Externo | Em Uso | Cache de dados, gerenciamento de sessões, filas de mensagens e outras operações de alta performance. | Utiliza `REDIS_URL` do `.env`. | Melhorar a performance e escalabilidade do backend, especialmente para funcionalidades em tempo real. | 
| **Cloudinary** | Externo | Em Uso | Serviço de gerenciamento de imagens e vídeos na nuvem (upload, transformação, entrega). | Utiliza `CLOUDINARY_CLOUD_NAME`, `CLOUDINARY_API_KEY`, `CLOUDINARY_API_SECRET` do `.env`. | Gerenciamento eficiente de mídias (avatares, banners, arquivos de chat). | 
| **JWT (JSON Web Tokens)** | Interno | Em Uso | Geração e validação de tokens de autenticação para proteger as rotas da API. | Utiliza `JWT_SECRET` do `.env`. | Segurança na comunicação entre frontend e backend. | 
| **Express.js** | Interno | Em Uso | Framework web para construir a API RESTful do backend. | Core do backend. | Fornecer uma estrutura robusta para a API. | 
| **Serviços de Áudio (Notificação)** | Interno | Em Uso | Lógica para processar e enviar notificações de áudio. | Integrado com FCM e lógica de chat. | Alertar usuários sobre novas mensagens ou eventos importantes. | 
| **Rotas API (adminRoutes, authRoutes, userRoutes, etc.)** | Interno | Em Uso | Definição dos endpoints da API para diferentes funcionalidades. | Verificado em `backend_routes_full.txt`. | Estruturar a comunicação com o frontend. | 

### 4.2. Frontend (Flutter/Dart)

| Ferramenta/Serviço | Tipo | Status de Uso | Descrição e Função | Observações | Intenção Original / Futura | 
|---|---|---|---|---|---|
| **Firebase Core** | Externo | Em Uso | Inicialização do Firebase no aplicativo. | Essencial para qualquer serviço Firebase. | Conectar o aplicativo aos serviços Firebase. | 
| **Firebase Auth** | Externo | Em Uso | Autenticação de usuários (login, registro, etc.). | Integrado com `AuthService`. | Gerenciamento de contas de usuário. | 
| **Firebase Messaging (FCM)** | Externo | Em Uso | Recebimento de notificações push. | Integrado com `FirebaseService`. | Receber notificações do backend. | 
| **Firebase Crashlytics** | Externo | Em Uso | Monitoramento de falhas e erros em tempo real. | Configurado em `main.dart`. | Identificar e corrigir bugs rapidamente. | 
| **Sentry** | Externo | Em Uso | Monitoramento de erros e performance. | Configurado em `main.dart`. | Monitoramento adicional de erros e performance. | 
| **`http` (package)** | Interno | Em Uso | Realização de requisições HTTP para a API do backend. | Utilizado por `ApiService`. | Comunicação com a API RESTful. | 
| **`provider` (package)** | Interno | Em Uso | Gerenciamento de estado no aplicativo. | Amplamente utilizado para injeção de dependências e reatividade. | Facilitar o gerenciamento de estado e a arquitetura do aplicativo. | 
| **`socket_io_client` (package)** | Interno | Em Uso | Comunicação em tempo real com o backend via WebSockets. | Utilizado por `SocketService`. | Funcionalidades de chat e presença em tempo real. | 
| **`image_picker` (package)** | Interno | Em Uso | Seleção de imagens e vídeos da galeria do dispositivo. | Implementado em `contextual_chat_screen.dart`. | Permitir o upload de mídias no chat. | 
| **`file_picker` (package)** | Interno | Não Usado (Ainda) | Seleção de arquivos de qualquer tipo. | Potencialmente útil para upload de documentos. | Almejado para expandir as capacidades de upload de arquivos. | 
| **`jitsi_meet_flutter_sdk` (package)** | Interno | Em Uso | Integração com o Jitsi Meet para chamadas de voz/vídeo. | Utilizado por `VoIPService`. | Funcionalidades de chamadas VoIP. | 
| **`path_provider` (package)** | Interno | Em Uso | Obtenção de caminhos para diretórios do sistema de arquivos. | Útil para armazenamento temporário de arquivos. | Gerenciamento de arquivos locais. | 
| **`shared_preferences` (package)** | Interno | Em Uso | Armazenamento de dados simples em disco (preferências do usuário, tokens). | Utilizado por `AuthService`. | Persistência de dados de sessão. | 
| **`flutter_local_notifications` (package)** | Interno | Em Uso | Exibição de notificações locais no dispositivo. | Utilizado para notificações de chamadas e mensagens. | Melhorar a experiência do usuário com notificações visuais. | 
| **`permission_handler` (package)** | Interno | Em Uso | Gerenciamento de permissões do dispositivo (microfone, câmera, armazenamento). | Essencial para chamadas VoIP e acesso a arquivos. | Garantir o acesso necessário aos recursos do dispositivo. | 
| **`flutter_secure_storage` (package)** | Interno | Não Usado (Ainda) | Armazenamento seguro de dados sensíveis (tokens, credenciais). | Mais seguro que `shared_preferences` para dados sensíveis. | Almejado para aumentar a segurança do armazenamento de credenciais. | 
| **`cached_network_image` (package)** | Interno | Em Uso | Exibição de imagens de rede com cache. | Utilizado em vários widgets. | Melhorar a performance e a experiência do usuário ao carregar imagens. | 
| **`url_launcher` (package)** | Interno | Em Uso | Abrir URLs externas (navegador, e-mail, telefone). | Potencialmente útil para links em mensagens ou perfis. | Permitir a interação com recursos externos. | 

## 5. Análise de Código Morto e Intenções de Revitalização

Durante a análise, alguns arquivos e componentes foram identificados como "código morto" ou não utilizados. A intenção é revitalizar funcionalidades almejadas ou remover o código desnecessário para otimizar o projeto.

### 5.1. Código Morto Identificado

*   **`/home/ubuntu/frontend/lib/config/api_config.dart`**
    *   **Conteúdo:** Define `ApiConfig` com `baseUrl` como "YOUR_API_BASE_URL_HERE".
    *   **Análise:** Placeholder ou configuração inicial não utilizada. O `backendBaseUrl` real é definido em `lib/utils/constants.dart` e é o que `ApiService` utiliza.
    *   **Intenção:** Mover para uma pasta de código morto ou remover, pois não está em uso e sua funcionalidade é redundante.
*   **`/home/ubuntu/frontend/lib/index.dart`**
    *   **Conteúdo:** Exporta vários modelos (`channel_model.dart`, `clan_model.dart`, etc.) dentro da pasta `lib`.
    *   **Análise:** Arquivo de índice de exportação que não é importado por nenhum outro arquivo no projeto.
    *   **Intenção:** Mover para uma pasta de código morto ou remover, pois não está sendo utilizado.
*   **`/home/ubuntu/frontend/lib/models/index.dart`**
    *   **Conteúdo:** Exporta vários modelos (`channel_model.dart`, `clan_model.dart`, etc.) dentro da pasta `models`.
    *   **Análise:** Similar ao `lib/index.dart`, este arquivo é um índice de exportação que não é importado por nenhum outro arquivo.
    *   **Intenção:** Mover para uma pasta de código morto ou remover, pois não está sendo utilizado.
*   **`/home/ubuntu/frontend/lib/models/mission_type.dart`**
    *   **Conteúdo:** Define o enum `MissionType` (`daily`, `weekly`, `clan`).
    *   **Análise:** Não há importações diretas e as referências em `widgets/mission_card.dart` estão comentadas, indicando que o enum não está em uso ativo.
    *   **Intenção:** Mover para uma pasta de código morto ou remover, a menos que a funcionalidade de tipos de missão seja ativada.

### 5.2. Funcionalidades Almejadas (Placeholders e Revitalização)

O projeto contém placeholders e estruturas para funcionalidades que foram almejadas, mas ainda não estão totalmente implementadas ou ativas. A intenção é revitalizá-las e integrá-las plenamente.

*   **Upload de Arquivos no Chat:**
    *   **Status:** Estrutura básica (`UploadService`, campos no `Message` model) presente, mas a integração completa na UI e o fluxo de upload precisam ser finalizados.
    *   **Intenção:** Implementar a seleção de arquivos (imagens, vídeos, documentos) na tela de chat, o upload para o Cloudinary (via backend) e a exibição correta desses arquivos nas mensagens.
*   **Presença de Usuários (Online/Offline):**
    *   **Status:** Lógica de `atualizarStatusPresenca` no `ChatService` e `AppLifecycleReactor` presente, mas a exibição visual da presença e a integração completa com o `SocketService` podem precisar de ajustes.
    *   **Intenção:** Garantir que o status online/offline dos usuários seja corretamente atualizado e exibido em listas de membros e perfis.
*   **QRR (Quick Response Report), Instaclan e Instaguerra:**
    *   **Status:** Telas (`qrr_list_screen.dart`, `instaclan_feed_screen.dart`, `clan_wars_list_screen.dart`) e modelos (`qrr_model.dart`, `clan_war_model.dart`) existem, mas a integração completa com o backend e a acessibilidade na UI (abas/widgets) precisam ser verificadas e finalizadas.
    *   **Intenção:** Garantir que essas funcionalidades estejam totalmente operacionais e facilmente acessíveis a partir da interface principal do aplicativo (ex: `HomeScreen`, painéis de clã/federação, painel de administração).
*   **`flutter_secure_storage`:**
    *   **Status:** Pacote importado, mas não há uso explícito para armazenamento seguro de credenciais.
    *   **Intenção:** Substituir o uso de `shared_preferences` para armazenamento de dados sensíveis (como tokens de autenticação) por `flutter_secure_storage` para aumentar a segurança.
*   **`file_picker`:**
    *   **Status:** Pacote importado, mas não há uso explícito para seleção de arquivos genéricos.
    *   **Intenção:** Integrar `file_picker` para permitir o upload de outros tipos de arquivos (documentos, áudios) além de imagens/vídeos no chat ou em outras funcionalidades.

## 6. Estado Atual dos Erros e Próximos Passos

As correções realizadas até o momento abordaram uma parte significativa dos erros iniciais, especialmente aqueles relacionados a argumentos e tipagem. No entanto, o último log de erros (fornecido em `pasted_content.txt`) revelou novos problemas, muitos deles decorrentes das alterações para implementar funcionalidades como upload de arquivos e aprimoramentos no chat.

### 6.1. Resumo dos Novos Erros

Os erros mais recentes podem ser agrupados em:

*   **Erros de Sintaxe e Estrutura (`main.dart`):** Problemas na configuração do `MultiProvider` e inicialização de serviços.
*   **Erros de Tipagem e Parâmetros Ausentes (`message_model.dart`, `chat_service.dart`, telas de chat):** Campos não inicializados, argumentos faltando ou com tipos incorretos em chamadas de métodos.
*   **Erros de Referência e Definição (`admin_service.dart`, `StatsService`, `call_page.dart`, `home_screen.dart`, `incoming_call_overlay.dart`):** Métodos ou classes não encontrados, uso incorreto de parâmetros.
*   **Erros de Lógica Assíncrona (`call_screen.dart`):** Uso de `await` fora de funções `async`.
*   **Erros de Tipagem (`int` vs `String`):** Atribuição de `String` a parâmetros `int` em relatórios administrativos.

### 6.2. Plano de Ação para Próximas Correções

Com base na análise detalhada em `impacto_e_correcao_erros_pos_atualizacao.md` e `locais_exatos_correcoes.md`, os próximos passos para a correção e otimização do projeto são:

1.  **Prioridade Máxima:** Corrigir os erros de sintaxe em `main.dart` e os erros de tipagem/parâmetros ausentes nos modelos e serviços de chat. Estes são os mais impeditivos para a compilação e execução do aplicativo.
2.  **Revisão e Implementação:** Abordar os erros de referência e definição, garantindo que todos os serviços e classes sejam corretamente inicializados e utilizados.
3.  **Lógica Assíncrona:** Corrigir problemas de lógica assíncrona, especialmente em `call_screen.dart`.
4.  **Consistência de Dados:** Resolver os erros de tipagem (`int` vs `String`) em `admin_reports_screen.dart`.
5.  **Revitalização de Funcionalidades:** Após a estabilização do projeto, focar na implementação completa e teste das funcionalidades almejadas (upload de arquivos, presença, QRR, Instaclan, Instaguerra).
6.  **Auditoria de Código Morto:** Mover os arquivos identificados como código morto para uma pasta separada, conforme solicitado, para manter o projeto limpo e otimizado.

## 7. Conclusão e Intenção Futura

O projeto FederacaoMAD é complexo e ambicioso, com um grande potencial. A intenção é transformá-lo em um aplicativo robusto, otimizado e livre de falhas, que entregue todas as funcionalidades almejadas. Este documento serve como um compromisso com a qualidade e a clareza, garantindo que o conhecimento sobre o projeto seja compartilhado e que o desenvolvimento futuro seja eficiente e alinhado com a visão original.

Com a aplicação sistemática das correções e a revitalização das funcionalidades, o FederacaoMAD estará pronto para oferecer uma experiência de usuário excepcional e cumprir seu propósito como uma plataforma de comunicação VoIP de ponta para clãs e federações.

