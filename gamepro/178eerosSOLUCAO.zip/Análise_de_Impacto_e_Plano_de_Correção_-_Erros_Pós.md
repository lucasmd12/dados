# Análise de Impacto e Plano de Correção - Erros Pós-Atualização

Este documento detalha a análise dos novos erros reportados após as últimas correções e atualizações no projeto FederacaoMAD. O objetivo é fornecer um entendimento claro do impacto de cada erro e um plano de ação preciso para corrigi-los, garantindo a estabilidade e funcionalidade do aplicativo.

## Resumo dos Erros

O novo log de erros apresenta uma série de problemas que podem ser categorizados em:

1.  **Erros de Sintaxe e Estrutura (`main.dart`):** Uma grande parte dos erros iniciais (1-31) aponta para problemas de sintaxe no arquivo `main.dart`, especificamente relacionados a caracteres inesperados e falta de identificadores. Isso sugere que houve uma alteração na estrutura do `MultiProvider` ou na inicialização de serviços que introduziu esses problemas.
2.  **Erros de Tipagem e Parâmetros Ausentes (`message_model.dart`, `chat_service.dart`, `screens/chat/*_chat_screen.dart`, `widgets/chat_widget.dart`):** Vários erros (32-39, 56, 59-92, 93-149, 155-158, 162-172) indicam que os parâmetros esperados em construtores de modelos (`Message`) ou em chamadas de métodos (`sendMessage`, `getMessages`, `listenToMessages`) não estão sendo fornecidos ou estão com tipos incorretos. Isso é um impacto direto das mudanças para suportar upload de arquivos e aprimoramentos no chat.
3.  **Erros de Referência e Definição (`admin_main_dashboard.dart`, `admin_reports_screen.dart`, `admin_service.dart`, `call_page.dart`, `call_screen.dart`, `home_screen.dart`, `incoming_call_overlay.dart`, `member_list_item.dart`):** Erros como "isn't defined" (40-42, 47, 53, 56, 151, 153, 154, 176, 177, 178) e "isn't a type" (40) indicam que classes, métodos ou parâmetros não estão sendo reconhecidos ou estão sendo usados de forma incorreta. Isso pode ser devido a refatorações incompletas ou a problemas de importação.
4.  **Erros de Lógica Assíncrona (`call_screen.dart`):** Erros relacionados a `await` fora de funções `async` (50) indicam problemas na lógica de chamadas assíncronas.

## Impacto Geral no Projeto

Esses erros, se não corrigidos, impedirão que o aplicativo compile ou, se compilar, causarão falhas em tempo de execução, especialmente nas funcionalidades de chat, chamadas VoIP e painéis administrativos. A maioria dos erros está concentrada em áreas críticas de comunicação e gerenciamento de dados, o que significa que o aplicativo não funcionará conforme o esperado.

## Plano de Correção Detalhado

O plano de correção será executado de forma incremental, focando em resolver os erros de forma que cada correção não introduza novos problemas e que o projeto permaneça funcional em cada etapa. A prioridade será dada aos erros de sintaxe e tipagem, que são os mais impeditivos.

### 1. Correção dos Erros de Sintaxe e Estrutura em `main.dart` (Erros 1-31)

**Causa:** As mensagens de erro indicam que a estrutura do `MultiProvider` ou a inicialização dos serviços foi alterada de forma incorreta, resultando em caracteres inesperados e falta de identificadores.

**Solução:**
*   Revisar cuidadosamente as linhas 165 a 179 e 261 a 262 em `lib/main.dart`.
*   Garantir que a sintaxe do `ChangeNotifierProvider` e a passagem de argumentos para os construtores dos serviços estejam corretas, seguindo a estrutura esperada do Flutter para injeção de dependências.
*   Verificar se todos os parênteses, colchetes e chaves estão balanceados e corretamente posicionados.
*   Exemplo de correção para `ChatService` (já realizada na última etapa, mas pode precisar de ajustes finos):
    ```dart
    ChangeNotifierProvider<ChatService>(create: (context) => ChatService(
      firebaseService: context.read<FirebaseService>(),
      authService: context.read<AuthService>(),
      socketService: context.read<SocketService>(),
      uploadService: context.read<UploadService>(), // Garantir que UploadService seja passado
    )),
    ```

### 2. Correção dos Erros de Tipagem e Parâmetros Ausentes no `Message` Model e Serviços de Chat (Erros 32-39, 56, 59-92, 93-149, 155-158, 162-172)

**Causa:** Introdução de novos campos no `Message` model e alterações nas assinaturas dos métodos `sendMessage`, `getMessages` e `listenToMessages` no `ChatService` e suas chamadas nas telas de chat (`contextual_chat_screen.dart`, `clan_text_chat_screen.dart`, `federation_text_chat_screen.dart`, `global_chat_screen.dart`, `chat_widget.dart`).

**Solução:**
*   **`lib/models/message_model.dart` (Erros 32-39):**
    *   Garantir que todos os campos (`fileSize`, `thumbnailUrl`, `callId`, `callStatus`, `callType`, `callDuration`) sejam inicializados no construtor da classe `Message` e que seus tipos estejam corretos (provavelmente anuláveis `?`).
    *   Verificar se o método `fromMap` está mapeando corretamente esses novos campos a partir do `Map<String, dynamic>`.
    *   O erro `The name 'fileSize' is already defined` (39) sugere que há uma duplicidade na definição do getter `fileSize` ou no campo da classe. Será necessário remover a duplicidade, mantendo apenas uma definição para o campo ou getter.
*   **`lib/services/chat_service.dart` (Erros 155-158):**
    *   O erro `Undefined class 'File'` (155) indica a falta de importação de `dart:io`. Adicionar `import 'dart:io';`.
    *   Os erros `The argument type 'Map<String, String>' can't be assigned to the parameter type 'String'` (156) e `3 positional arguments expected by 'sendMessage', but 2 found` (157) sugerem que a assinatura do `sendMessage` foi alterada para aceitar um `File` ou outros parâmetros, e as chamadas precisam ser atualizadas.
    *   O erro `The method 'updatePresence' isn't defined for the type 'SocketService'` (158) indica que o método `updatePresence` não existe no `SocketService` ou foi renomeado. Será necessário verificar a implementação do `SocketService` e ajustar a chamada no `ChatService`.
*   **Telas de Chat e `chat_widget.dart` (Erros 56, 59-92, 93-149, 162-172):**
    *   Atualizar todas as chamadas para `chatService.sendMessage` e `chatService.getMessages` para que correspondam às novas assinaturas dos métodos, incluindo os parâmetros `entityId`, `message`, `chatType`, `fileUrl`, `messageType`, `fileName`, `fileSize` conforme necessário.
    *   O erro `The getter 'isSystem' isn't defined for the type 'Message'` (56) em `contextual_chat_screen.dart` indica que o `Message` model não possui um getter `isSystem`. Será necessário adicionar este getter ao `Message` model ou ajustar a lógica na tela de chat para verificar se a mensagem é do sistema de outra forma (ex: `senderId` específico).
    *   O erro `The method '_formatTimestamp' isn't defined` (57) em `contextual_chat_screen.dart` indica que esta função auxiliar precisa ser definida dentro da classe `_ContextualChatScreenState` ou ser acessível de outra forma.
    *   O erro `This expression has a type of 'void' so its value can't be used` (93, 160, 169) geralmente ocorre quando se tenta usar o retorno de uma função `void` em um contexto que espera um valor. Isso pode ser resolvido removendo a atribuição ou ajustando a lógica.

### 3. Correção dos Erros de Referência e Definição (Erros 40-42, 47, 53, 56, 151, 153, 154, 176, 177, 178)

**Causa:** Problemas de importação, refatorações incompletas ou uso incorreto de tipos.

**Solução:**
*   **`lib/screens/admin/admin_main_dashboard.dart` (Erro 40):** O erro `The name 'StatsService' isn't a type, so it can't be used as a type argument` sugere que `StatsService` não está sendo reconhecido como um tipo. Verificar a importação de `StatsService` e se a classe está corretamente definida.
*   **`lib/screens/admin/admin_reports_screen.dart` (Erros 41-42):** Os métodos `getUserStats` e `getClanFederationStats` não estão definidos para `AdminService`. Isso significa que esses métodos foram movidos para outro serviço (provavelmente `StatsService`) ou precisam ser implementados no `AdminService`. Com base na análise anterior, eles foram movidos para `StatsService`, então as chamadas em `admin_reports_screen.dart` precisam ser atualizadas para usar `StatsService`.
*   **`lib/screens/call_page.dart` (Erro 47):** O getter `isIncomingCall` não está definido. Isso é resultado da remoção deste parâmetro. A lógica que o utilizava precisa ser adaptada para não depender mais dele, talvez usando o `CallStatus` do `VoIPService`.
*   **`lib/screens/call_screen.dart` (Erro 53):** O parâmetro nomeado `roomId` não está definido. Verificar a assinatura do construtor ou método que está sendo chamado e adicionar `roomId` se necessário.
*   **`lib/screens/home_screen.dart` (Erro 151):** O erro `The name 'QRRListScreen' isn't a class` indica que `QRRListScreen` não está sendo reconhecido como uma classe. Verificar a importação e a definição da classe `QRRListScreen`.
*   **`lib/services/admin_service.dart` (Erros 153-154):** `Undefined name '_apiService'`. Isso significa que a instância de `ApiService` não está sendo injetada ou inicializada corretamente no `AdminService`. Adicionar `ApiService` ao construtor de `AdminService` e inicializá-lo.
*   **`lib/widgets/incoming_call_overlay.dart` (Erros 173-176):** Similar ao `call_page.dart`, `isIncomingCall` não está definido. Além disso, `callId` e `roomId` podem estar faltando ou sendo usados incorretamente. Ajustar as chamadas para `CallPage` ou outros componentes para fornecer os parâmetros corretos.
*   **`lib/widgets/member_list_item.dart` (Erros 177-178):** `roomId` e `call` não estão definidos. Verificar o contexto em que `MemberListItem` é usado e garantir que esses parâmetros sejam passados corretamente.

### 4. Correção dos Erros de Lógica Assíncrona (Erros 48-52, 54-55)

**Causa:** Uso de `await` fora de um contexto `async` ou problemas na passagem de parâmetros para chamadas de função.

**Solução:**
*   **`lib/screens/call_screen.dart` (Erros 48-52, 54-55):**
    *   O erro `The await expression can only be used in an async function` (50) indica que a função que contém o `await` precisa ser marcada como `async`.
    *   Os erros `A function body must be provided` (48) e `Expected to find ','` (49) sugerem que há um problema na definição de uma função ou na sua chamada.
    *   Os erros `Too many positional arguments` (51) e `The named parameter 'callId' is required, but there's no corresponding argument` (52, 55) indicam que a chamada para uma função (provavelmente relacionada a chamadas VoIP) está incorreta. Será necessário verificar a assinatura da função e ajustar a chamada para passar os argumentos corretos, possivelmente `callId` e `roomId`.

### 5. Correção de Erros de Tipagem para `int` vs `String` (Erros 43-46)

**Causa:** Tentativa de atribuir um valor `String` a um parâmetro que espera um `int`.

**Solução:**
*   **`lib/screens/admin/admin_reports_screen.dart` (Erros 43-46):**
    *   As linhas 72-75 estão tentando atribuir valores `String` a parâmetros `int`. Isso provavelmente ocorre ao tentar exibir dados estatísticos que vêm como `String` do backend, mas são esperados como `int` na UI.
    *   Converter os valores `String` para `int` usando `int.tryParse()` ou `int.parse()` antes de usá-los. É recomendável usar `int.tryParse()` para evitar exceções caso a string não seja um número válido.
    *   Exemplo: `int.tryParse(data['totalUsers'] ?? '0') ?? 0`

## Próximos Passos e Recomendações

1.  **Execução Sequencial:** As correções devem ser aplicadas sequencialmente, começando pelos erros de sintaxe e depois pelos de tipagem e referência. Cada correção deve ser testada para garantir que não introduza novos problemas.
2.  **Revisão de `main.dart`:** Dada a quantidade de erros de sintaxe em `main.dart`, uma revisão completa da seção de `MultiProvider` e inicialização de serviços é crucial.
3.  **Consistência de Modelos e Serviços:** Garantir que as definições dos modelos (especialmente `Message`) e as assinaturas dos métodos nos serviços (`ChatService`, `AdminService`, `StatsService`, `VoIPService`) estejam alinhadas com o que é esperado pelas telas e widgets que os utilizam.
4.  **Verificação de Importações:** Sempre verificar se todas as classes e funções utilizadas estão corretamente importadas.
5.  **Testes:** Após cada conjunto de correções, é fundamental compilar e executar o aplicativo para verificar se os erros foram resolvidos e se novas regressões não foram introduzidas.

Este plano visa abordar todos os erros reportados de forma sistemática, minimizando o risco de quebras e garantindo a funcionalidade do projeto FederacaoMAD. Estou pronto para iniciar a implementação dessas correções.

