# Locais Exatos para Correções no Projeto FederacaoMAD

Este documento serve como um guia rápido e preciso para as intervenções necessárias no código do projeto FederacaoMAD, com base na análise de erros mais recente. Ele lista os arquivos e as áreas específicas que requerem atenção para resolver os problemas identificados.

## 1. Erros de Sintaxe e Estrutura

**Arquivo:** `lib/main.dart`
*   **Linhas:** 165 a 179 e 261 a 262
*   **Problema:** Sintaxe incorreta na configuração do `MultiProvider` e na inicialização de serviços. Caracteres inesperados e falta de identificadores.
*   **Ação:** Revisar a sintaxe, garantir o balanceamento de parênteses/colchetes/chaves e a correta passagem de argumentos para os construtores dos serviços (ex: `ChatService` precisa de `firebaseService`, `authService`, `socketService`, `uploadService`).

## 2. Erros de Tipagem e Parâmetros Ausentes (Modelos e Serviços de Chat)

### 2.1. `Message` Model
**Arquivo:** `lib/models/message_model.dart`
*   **Problema:** Campos `fileSize`, `thumbnailUrl`, `callId`, `callStatus`, `callType`, `callDuration` não inicializados ou com tipos incorretos. Duplicidade na definição de `fileSize`.
*   **Ação:**
    *   Garantir que todos os campos mencionados sejam inicializados no construtor e que seus tipos sejam anuláveis (`?`).
    *   Verificar e corrigir o método `fromMap` para mapear corretamente esses novos campos.
    *   Remover a duplicidade na definição de `fileSize`, mantendo apenas uma.

### 2.2. `ChatService`
**Arquivo:** `lib/services/chat_service.dart`
*   **Problema:**
    *   `Undefined class 'File'` (erro 155).
    *   Argumentos incorretos para `sendMessage` (erro 156, 157).
    *   `updatePresence` não definido para `SocketService` (erro 158).
*   **Ação:**
    *   Adicionar `import 'dart:io';`.
    *   Ajustar a assinatura de `sendMessage` e suas chamadas para aceitar os parâmetros corretos (ex: `File` para upload).
    *   Verificar a implementação de `SocketService` e ajustar a chamada para `updatePresence` no `ChatService`.

### 2.3. Telas de Chat e `chat_widget.dart`
**Arquivos:**
*   `lib/screens/chat/contextual_chat_screen.dart`
*   `lib/screens/clan_text_chat_screen.dart`
*   `lib/screens/federation_text_chat_screen.dart`
*   `lib/screens/global_chat_screen.dart`
*   `lib/widgets/chat_widget.dart`
*   **Problema:**
    *   Chamadas incorretas para `chatService.sendMessage` e `chatService.getMessages` (erros 59-92, 93-149, 162-172).
    *   `isSystem` não definido para `Message` (erro 56 em `contextual_chat_screen.dart`).
    *   `_formatTimestamp` não definido (erro 57 em `contextual_chat_screen.dart`).
    *   Uso de expressão `void` em contexto de valor (erros 93, 160, 169).
*   **Ação:**
    *   Atualizar todas as chamadas para `sendMessage` e `getMessages` para corresponderem às novas assinaturas, incluindo `entityId`, `message`, `chatType`, `fileUrl`, `messageType`, `fileName`, `fileSize`.
    *   Adicionar o getter `isSystem` ao `Message` model ou ajustar a lógica na tela de chat.
    *   Definir `_formatTimestamp` dentro de `_ContextualChatScreenState` ou torná-lo acessível.
    *   Remover atribuições de funções `void` ou ajustar a lógica.

## 3. Erros de Referência e Definição

### 3.1. `admin_main_dashboard.dart`
**Arquivo:** `lib/screens/admin/admin_main_dashboard.dart`
*   **Problema:** `StatsService` não reconhecido como tipo (erro 40).
*   **Ação:** Verificar importação e definição correta de `StatsService`.

### 3.2. `admin_reports_screen.dart`
**Arquivo:** `lib/screens/admin/admin_reports_screen.dart`
*   **Problema:** Métodos `getUserStats` e `getClanFederationStats` não definidos para `AdminService` (erros 41-42).
*   **Ação:** Atualizar as chamadas para usar `StatsService` em vez de `AdminService` para esses métodos.

### 3.3. `call_page.dart`
**Arquivo:** `lib/screens/call_page.dart`
*   **Problema:** Getter `isIncomingCall` não definido (erro 47).
*   **Ação:** Adaptar a lógica para não depender mais de `isIncomingCall`, talvez usando `CallStatus` do `VoIPService`.

### 3.4. `call_screen.dart`
**Arquivo:** `lib/screens/call_screen.dart`
*   **Problema:** Parâmetro nomeado `roomId` não definido (erro 53).
*   **Ação:** Verificar a assinatura do construtor/método e adicionar `roomId` se necessário.

### 3.5. `home_screen.dart`
**Arquivo:** `lib/screens/home_screen.dart`
*   **Problema:** `QRRListScreen` não reconhecido como classe (erro 151).
*   **Ação:** Verificar importação e definição correta de `QRRListScreen`.

### 3.6. `admin_service.dart`
**Arquivo:** `lib/services/admin_service.dart`
*   **Problema:** `_apiService` indefinido (erros 153-154).
*   **Ação:** Injetar ou inicializar corretamente a instância de `ApiService` no construtor de `AdminService`.

### 3.7. `incoming_call_overlay.dart`
**Arquivo:** `lib/widgets/incoming_call_overlay.dart`
*   **Problema:** `isIncomingCall` não definido; `callId` e `roomId` faltando/incorretos (erros 173-176).
*   **Ação:** Ajustar as chamadas para `CallPage` ou outros componentes para fornecer os parâmetros corretos.

### 3.8. `member_list_item.dart`
**Arquivo:** `lib/widgets/member_list_item.dart`
*   **Problema:** `roomId` e `call` não definidos (erros 177-178).
*   **Ação:** Verificar o contexto de uso e garantir que esses parâmetros sejam passados corretamente.

## 4. Erros de Lógica Assíncrona

### 4.1. `call_screen.dart`
**Arquivo:** `lib/screens/call_screen.dart`
*   **Problema:**
    *   Uso de `await` fora de função `async` (erro 50).
    *   Problemas na definição/chamada de função (erros 48-49).
    *   Argumentos posicionais excessivos ou parâmetros nomeados ausentes (erros 51-52, 54-55).
*   **Ação:**
    *   Marcar a função contendo `await` como `async`.
    *   Corrigir a definição e/ou chamada da função.
    *   Ajustar a chamada da função para passar os argumentos corretos, como `callId` e `roomId`.

## 5. Erros de Tipagem (`int` vs `String`)

### 5.1. `admin_reports_screen.dart`
**Arquivo:** `lib/screens/admin/admin_reports_screen.dart`
*   **Linhas:** 72-75
*   **Problema:** Tentativa de atribuir `String` a parâmetros `int`.
*   **Ação:** Converter os valores `String` para `int` usando `int.tryParse()` ou `int.parse()` antes de usá-los (ex: `int.tryParse(data['totalUsers'] ?? '0') ?? 0`).

Este documento serve como um mapa para as próximas etapas de correção. Recomenda-se seguir a ordem lógica das seções para garantir uma correção sistemática e evitar a introdução de novos problemas.

